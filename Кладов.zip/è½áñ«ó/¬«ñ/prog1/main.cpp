#include "lib.h"
#include <iostream>

int main() {
  application app;
  app.init();
  app.exec();
  return 0;
}
