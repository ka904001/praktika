#include "lib.h"
#include <iostream>
using namespace std;
int main() {
  application app;
  app.init();
  app.exec();
  return 0;
}
